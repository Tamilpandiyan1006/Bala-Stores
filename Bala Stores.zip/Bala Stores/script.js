function toggleSection(sectionId) {
    document.getElementById('price-list').style.display = 'none';
    document.getElementById('stock-list').style.display = 'none';
    document.getElementById(sectionId).style.display = 'block';
}

function addNewPriceRow() {
    const table = document.getElementById('price-list-body');
    const row = table.insertRow();
    
    const brandCell = row.insertCell(0);
    const riceVarietyCell = row.insertCell(1);
    const mrpPriceCell = row.insertCell(2);
    const ourPriceCell = row.insertCell(3);
    const quantityCell = row.insertCell(4);

    brandCell.innerHTML = `<input type="text" placeholder="Enter brand name">`;
    riceVarietyCell.innerHTML = `<input type="text" placeholder="Enter rice variety">`;
    mrpPriceCell.innerHTML = `<input type="number" placeholder="Enter MRP price">`;
    ourPriceCell.innerHTML = `<input type="number" placeholder="Enter our price">`;
    quantityCell.innerHTML = `<input type="number" placeholder="Enter quantity">`;
}

function addNewStockRow() {
    const stockList = document.getElementById('stock-list-body');
    const div = document.createElement('div');
    div.className = 'stock-item';
    
    div.innerHTML = `
        <label>Brand Name:</label>
        <input type="text" placeholder="Enter brand name">
        <label>Rice Variety:</label>
        <input type="text" placeholder="Enter rice variety">
        <label>Bag Size:</label>
        <input type="text" placeholder="Enter bag size">
        <label>Quantity (kgs):</label>
        <input type="number" placeholder="Enter quantity">
    `;
    
    stockList.appendChild(div);
}

function calculateTotal() {
    let total = 0;
    const priceInputs = document.querySelectorAll('#receipt-body input[type="number"]:nth-child(3)');

    priceInputs.forEach(input => {
        total += parseFloat(input.value) || 0;
    });

    document.getElementById('total-price').innerText = 'Total Price: ' + total.toFixed(2);
}

function printReceipt() {
    window.print();
}